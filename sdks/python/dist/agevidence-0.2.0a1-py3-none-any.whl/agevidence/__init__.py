"""AgEvidence Python SDK.

The SDK orchestrates Rails Developer OS APIs and delegates trust operations to
configured verifier tools. It does not sign receipts, compute receipt
commitments, or verify bundles internally.
"""

from ._version import __version__
from .async_client import AsyncClient
from .campaign import (
    ActivationPath,
    CampaignAccount,
    CampaignClient,
    CampaignContactRef,
    CampaignDashboard,
    CommercialHandoff,
    TechnicalQualification,
)
from .client import Client
from .demo import run_demo as demo
from .doctor import doctor
from .errors import AgEvidenceError
from .ingest import ingest
from .models import (
    ArtifactDownloadMetadata,
    ArtifactOrder,
    CountryAdapterInfo,
    CountryAdapterValidation,
    CountryDetermination,
    DeveloperProject,
    EvidenceCandidate,
    IntegrationEventStatus,
    Operation,
    PricingQuote,
    ProductCatalog,
    SourceRecord,
    WebhookEndpoint,
)
from .request_models import AgEvidenceRequest
from .transport import RetryPolicy

__all__ = [
    "AgEvidenceError",
    "AgEvidenceRequest",
    "ActivationPath",
    "ArtifactDownloadMetadata",
    "ArtifactOrder",
    "AsyncClient",
    "CampaignAccount",
    "CampaignClient",
    "CampaignContactRef",
    "CampaignDashboard",
    "Client",
    "CommercialHandoff",
    "CountryAdapterInfo",
    "CountryAdapterValidation",
    "CountryDetermination",
    "DeveloperProject",
    "demo",
    "doctor",
    "EvidenceCandidate",
    "IntegrationEventStatus",
    "ingest",
    "Operation",
    "PricingQuote",
    "ProductCatalog",
    "RetryPolicy",
    "SourceRecord",
    "TechnicalQualification",
    "WebhookEndpoint",
    "__version__",
]
