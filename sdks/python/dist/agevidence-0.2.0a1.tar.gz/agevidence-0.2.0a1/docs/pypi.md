# Agevidence

Portable evidence primitives for agricultural software.

## Install

```bash
pip install agevidence
```

## 60-second demo

```bash
agevidence demo
```

The demo uses synthetic local fixture data. It does not require a Rails server,
an Agevidence account, an API token, country-method configuration, or production
signing credentials.

## Python quickstart

```python
from agevidence.primitives import Observation
from agevidence.provenance import check

observation = Observation(
    subject="animal:982000001234",
    observable="liveweight",
    value=481.4,
    unit="kg",
    observed_at="2026-08-12T14:05:11Z",
)

report = check(observation)
print(report.structural_validity)
print(report.provenance_completeness)
```

## Local-first

Local primitives, fixtures, provenance checks and validation do not require an
Agevidence account or hosted service.

```bash
agevidence fixture show livestock-weight
agevidence ingest sample.json
agevidence explain sample.json
agevidence doctor
```

## Optional hosted services

`Client` and `AsyncClient` provide access to Agevidence institutional workflows
when required.

```python
from agevidence import Client, AsyncClient
```

Receipt signing, canonical commitments and bundle verification remain delegated
to the Rust trust boundary.
