"""Packaged SDK resource snapshots."""

